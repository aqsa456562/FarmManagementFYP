const weatherForecast = [
  { day: "Today", temp: "28°C", condition: "Sunny", icon: "☀️" },
  { day: "Tomorrow", temp: "26°C", condition: "Partly Cloudy", icon: "⛅" },
  { day: "Wednesday", temp: "25°C", condition: "Cloudy", icon: "☁️" },
  { day: "Thursday", temp: "24°C", condition: "Rain", icon: "🌧️" },
  { day: "Friday", temp: "27°C", condition: "Sunny", icon: "☀️" },
]

export default weatherForecast
